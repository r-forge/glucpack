Notes:

1) Most of the functions in MMIST can be cited from Mastuda and Defronzo paper Diabetes care 22, number 9 sept. 1999
2) The Last measurement in the glucdata set is from the cobelli paper and the units are different.
3) The dosage for OMNICARB was 75 grams
4) OGIS from the MARI paper used the equation for body surface are from Dubois D, Dubois EF. Clinical calorimetry, X: a formula to estimate surface area if height and weight be known. Arch Intern Med. 1916;17:863-891. 
4-2)BSA (m�) = 0.20247 x Height(m)^0.725 x Weight(kg)^0.425


